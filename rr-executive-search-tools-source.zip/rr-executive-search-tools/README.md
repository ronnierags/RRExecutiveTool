# RR Executive Search Tools

Standalone source for the RR Executive Search Tools compensation calculator and its Cloudflare Worker API. The app is built for the site root (`/`) and serves the UI and API from the same Worker. This repository is separate from the active RR and AllSearch projects.

## Included

- `app/`: the approved RR calculator interface, calculation model, scenario/version workspace, section flags, import/export, lead consent and admin screens.
- `worker.ts`, `functions/`, and `migrations/`: the tested Cloudflare Worker entry point, shared Pages-function handlers called by that Worker, and D1 migration. The Worker explicitly routes API requests; it does not depend on Pages Functions auto-discovery.
- `packages/api-client-react/` and `packages/api-zod/`: the source workspace packages required by the app and Worker.
- `wrangler.toml`: a template only. It contains no existing AllSearch Worker name, D1 ID, or credentials. Deployment is blocked until the template Worker and D1 values are replaced.

## Requirements and local commands

- Node.js 24
- pnpm 10.11.1 (`corepack enable` and `corepack prepare pnpm@10.11.1 --activate` if needed)

From this repository root:

For local administrator sign-in, copy `.env.example` to `.env` at this repository root and set the public Clerk key for your local Clerk application. Vite reads this root environment file; runtime secrets belong only in the separate, gitignored `.dev.vars` file. The public calculator also works when no Clerk key is configured.

```sh
pnpm install --frozen-lockfile
pnpm run dev
pnpm run typecheck
pnpm test
pnpm run build
```

The production static output is `app/dist/public`; source maps are disabled. `pnpm run dev` runs the Vite UI on port 5173. For an end-to-end local setup, use Wrangler's local Worker on port 8787 as well:

```sh
cp .dev.vars.example .dev.vars
pnpm run db:migrate:local
```

Keep the blank values in `.dev.vars` for a no-secrets, download-only check, or enter local test credentials in this gitignored file only if needed. `db:migrate:local` applies `migrations/0001_leads.sql` to Wrangler's local D1 database; it does not contact or modify a remote D1 database.

In terminal 1, start the local Worker/API:

```sh
pnpm run dev:api
```

This command builds/typechecks first, then runs `wrangler dev --local --port 8787`. It serves the built app and `/api/*` from the Worker at `http://localhost:8787`. In terminal 2, run `pnpm run dev`; Vite proxies `/api` and `/api/*` to the Worker, so the live Vite UI at `http://localhost:5173` can use the local PDF/lead API. `pnpm run dev` by itself is UI-only and needs the Worker terminal for API submissions.

With blank `.dev.vars`, this local verification makes no real email call: valid private RR requests can download their generated PDF, report that email was not delivered, and create no D1 lead row. The admin API fails closed with HTTP 401 while Clerk runtime credentials are blank. Once the Worker is running, optional smoke checks are:

```sh
curl -i http://localhost:8787/api/healthz
curl -i http://localhost:8787/api
curl -i http://localhost:8787/api/not-a-route
curl -i http://localhost:8787/api/admin/leads
```

Expect `200` JSON for health, `404` JSON for both unknown API paths, and `401` JSON for admin leads with blank Clerk secrets. The same API paths are proxied through Vite on port 5173. Do not put real secrets in committed files.

## Upload this source to GitHub

1. Download and extract the standalone `rr-executive-search-tools-source.zip`, or copy the contents of this directory into a new, empty GitHub repository. The files in this directory are the repository root; do not nest them under another project folder.
2. In GitHub, create a private or public repository as appropriate, then use **Add file → Upload files** to upload the root contents and commit them to the default branch. Alternatively, initialize a local repository here and push it to your new GitHub repository.
3. Confirm `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml`, `app/`, `worker.ts`, `functions/`, `packages/`, `migrations/`, and `wrangler.toml` are all at the repository root.
4. Do not commit `.env`, `.dev.vars`, Cloudflare credentials, Clerk secrets, or API keys. The included `.env.example` and `.dev.vars.example` deliberately contain blank values.

## Configure a new or intentionally selected Cloudflare Worker and D1

Do not use Cloudflare Pages. In Cloudflare, create a **Worker with Static Assets** or select the Worker you intend to use for this standalone RR application. Create a new D1 database for RR, or explicitly select the existing D1 database you intend RR to use. This setup does not silently reuse an AllSearch database.

Before deploying, edit `wrangler.toml` in the GitHub repository:

1. Replace `name = "rr-executive-search-tools-template"` with the exact Worker name you created or intentionally selected. Worker names must be lowercase letters, numbers, or hyphens.
2. Replace the D1 `database_name = "rr-executive-search-tools-template"` with the exact selected database name.
3. Replace `database_id = "00000000-0000-0000-0000-000000000000"` with the D1 database UUID shown in Cloudflare.
4. Commit these non-secret deployment identifiers. `pnpm run deploy` and remote `pnpm run db:migrate` both execute a preflight script that refuses template names or the placeholder database ID.

The template already specifies the Worker entry point, `nodejs_compat`, D1 binding `DB`, static assets at `app/dist/public`, SPA fallback, and `run_worker_first = ["/api", "/api/*"]`. Both the exact `/api` path and nested API paths are routed through the Worker, so unknown API routes return JSON 404 responses rather than SPA HTML. The Worker handles `/api/healthz`, `/api/leads`, `/api/admin/leads`, and `/api/admin/leads.csv`; non-API requests use the static asset binding.

### GitHub-connected Cloudflare Workers Builds

Connect the GitHub repository to the selected Worker using **Workers Builds** (not a Pages project). In the Worker's build settings set:

- Root directory: `/` (repository root)
- Build command: `pnpm run build`
- Deploy command: `pnpm run deploy`
- Build variable `PNPM_VERSION`: `10.11.1`
- Node version: `24` (also pinned by `.nvmrc` and the root `engines` field)
- Build variable `VITE_CLERK_PUBLISHABLE_KEY`: your own production Clerk publishable key, or leave unset to keep public calculator use enabled while showing an admin setup notice.

After adding or changing this publishable key, run a new build and deploy so the browser bundle receives it. Changing runtime variables alone does not update build-time values.

Workers Builds installs from the committed `pnpm-lock.yaml`; keep the lockfile in sync with manifests. Build-time `VITE_*` values are compiled into the public browser bundle. Never place a Clerk secret or other secret in a build variable.

The deploy preflight intentionally fails while the template Worker/D1 values remain. After editing and committing `wrangler.toml`, the preflight will allow deployment only when the Worker name, D1 name, and D1 UUID are populated.

### D1 schema and lead data

After confirming the target D1 binding in `wrangler.toml`, apply the migration from the local clone:

```sh
pnpm install --frozen-lockfile
pnpm run db:migrate
```

This runs `wrangler d1 migrations apply DB --remote` and creates the leads table and index defined in `migrations/0001_leads.sql`. Review the target account/database before approving any remote migration. A local-only migration command is available as `pnpm run db:migrate:local`.

Only leads whose optional recruiter-copy consent is checked are inserted into D1. An unchecked RR consent creates a PDF response without a D1 insert, recruiter BCC, or database lead record. The browser's calculator scenarios and version workspace remain browser-local; they are not uploaded as leads unless the visitor submits the compensation-plan form.

## Configure runtime variables and production Clerk

Runtime values are configured separately from build variables in the selected Worker under **Settings → Variables and Secrets**. Add:

| Variable | Cloudflare type | Purpose |
| --- | --- | --- |
| `CLERK_SECRET_KEY` | Secret | Secret key for the same production Clerk instance as the build-time publishable key |
| `ADMIN_EMAIL` | Variable | Exact email address of the authorized Clerk administrator |
| `RESEND_API_KEY` | Secret | Resend API key used to email generated PDFs |
| `RR_EMAIL_FROM` | Variable | Sender identity on a domain verified in Resend |
| `LEAD_NOTIFICATION_EMAIL` | Variable | Recruiter notification/BCC recipient, required for opted-in recruiter-copy delivery |

The local `.dev.vars.example` uses the same exact names, all with blank example values. Copy it to `.dev.vars` only for local work and supply local-only values there; `.dev.vars` is gitignored. Never copy Replit-injected environment keys, tokens, users, or credentials into this repository or assume they transfer to Cloudflare.

Create or use your own production Clerk application. Configure the production domain and any custom domain as Clerk allowed origins/redirect URLs; obtain that instance's production publishable key and secret key. Set the publishable key as the Workers Builds **build variable** `VITE_CLERK_PUBLISHABLE_KEY` and the matching secret as the Worker **runtime secret** `CLERK_SECRET_KEY`. Set `ADMIN_EMAIL` to the intended Clerk user's email. The API verifies the Clerk session token and checks that server-side allow-listed email. Keep Clerk sign-up restrictions and administrator membership intentional.

If no usable `VITE_CLERK_PUBLISHABLE_KEY` is supplied, the public calculator still works. `/admin` and sign-in routes show an authentication setup notice; Clerk provider and auth-token bridge hooks are not mounted. There is no authentication bypass or demo administrator. If frontend Clerk is configured but runtime Clerk values are absent or mismatched, backend administrator requests are rejected; correct the runtime settings before using admin tools.

For outbound email, verify the sending domain in Resend and use a verified sender in `RR_EMAIL_FROM`. PDFs are always returned for browser download after a valid submission. If Resend credentials/sender are missing or delivery is otherwise unsuccessful, the interface reports that email was not delivered; it does not claim a successful email. With consent unchecked, a successful email is addressed only to the user and has no recruiter BCC.

## Verify and maintain

After deployment:

1. Check `https://<your-worker-domain>/api/healthz`; expect `{"status":"ok"}`.
2. Open `/` and verify the calculator works without any Clerk configuration.
3. If Clerk is not configured, open `/admin` and confirm the setup notice appears. After setting production Clerk build/runtime values, sign in as the configured administrator and verify lead listing and CSV export. Unauthenticated API admin requests must be rejected.
4. Submit a private RR plan with recruiter-copy consent unchecked. Confirm a PDF downloads; with valid mail configuration, only the user receives email. Confirm no D1 row is created and the request has no recruiter BCC.
5. If testing consented submissions, configure `LEAD_NOTIFICATION_EMAIL`. Confirm only opted-in leads are stored and the opted-in email includes that notification address as BCC.
6. Confirm missing/invalid email configuration leaves the PDF download available and the UI truthfully reports that email was not delivered.

### Backups and browser-origin changes

The D1 database contains opted-in recruiter leads only. Back up any selected existing database before migrating or changing routing; use Cloudflare D1 export/backup tools and retain the backup outside this source repository. The browser's saved scenario versions use browser storage, which is scoped to the exact site origin. Before moving to a new hostname or changing scheme/port, use the calculator's version export/download to save the JSON backup on each browser, then import it after visiting the new origin. Browser scenarios are not transferred by a Worker deployment.

## Verification

```sh
pnpm install --frozen-lockfile
pnpm run typecheck
pnpm test
pnpm run build
pnpm exec wrangler deploy --dry-run
```

The preflight is also independently checkable with `node scripts/deploy-preflight.mjs`; with the untouched template values it should exit non-zero and state that deployment was blocked. The dry-run validates the Worker/static asset bundle and does not publish it. `pnpm run deploy` and `pnpm run db:migrate` are live remote operations; do not run them until you have reviewed the exact selected Worker and D1 configuration.