import type { LeadInput } from "./generated/types";

type LeadSharingInput = Pick<LeadInput, "consent" | "scenario">;

export function isPrivateRrLead(lead: LeadSharingInput): boolean {
  return lead.scenario.brand === "rr" && lead.consent === false;
}

export function isLeadConsentValid(lead: LeadSharingInput): boolean {
  return lead.consent === true || isPrivateRrLead(lead);
}

export function getLeadSharingPolicy(lead: LeadSharingInput) {
  const privateRr = isPrivateRrLead(lead);
  return {
    storeLead: !privateRr,
    notifyRecruiter: !privateRr,
    requiresNotificationAddress: !privateRr,
  } as const;
}