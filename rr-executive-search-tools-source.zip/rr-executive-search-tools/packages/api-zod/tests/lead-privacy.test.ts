import assert from "node:assert/strict";
import test from "node:test";
import { CreateLeadResponse } from "../src/generated/api";
import type { LeadInput } from "../src/generated/types";
import { getLeadSharingPolicy, isLeadConsentValid } from "../src/lead-privacy";

function lead(brand: "rr" | "allsearch" | undefined, consent: boolean): Pick<LeadInput, "consent" | "scenario"> {
  return { consent, scenario: { brand } } as Pick<LeadInput, "consent" | "scenario">;
}

test("RR false consent is valid and suppresses storage and recruiter notification", () => {
  const request = lead("rr", false);
  assert.equal(isLeadConsentValid(request), true);
  assert.deepEqual(getLeadSharingPolicy(request), {
    storeLead: false,
    notifyRecruiter: false,
    requiresNotificationAddress: false,
  });
});

test("RR true consent preserves lead storage and recruiter notification", () => {
  const request = lead("rr", true);
  assert.equal(isLeadConsentValid(request), true);
  assert.deepEqual(getLeadSharingPolicy(request), {
    storeLead: true,
    notifyRecruiter: true,
    requiresNotificationAddress: true,
  });
});

test("AllSearch false consent and consent without an RR brand are invalid", () => {
  assert.equal(isLeadConsentValid(lead("allsearch", false)), false);
  assert.equal(isLeadConsentValid(lead(undefined, false)), false);
});

test("lead receipts support a successful nonstored response without an id", () => {
  assert.deepEqual(CreateLeadResponse.parse({
    pdfBase64: "cGRm",
    fileName: "rr-executive-search-compensation-plan-private.pdf",
    emailSent: true,
  }), {
    pdfBase64: "cGRm",
    fileName: "rr-executive-search-compensation-plan-private.pdf",
    emailSent: true,
  });
});