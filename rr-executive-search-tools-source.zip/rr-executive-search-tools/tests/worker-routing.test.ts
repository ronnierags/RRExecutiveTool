import assert from "node:assert/strict";
import test from "node:test";
import worker from "../worker";

async function request(path: string, method = "GET") {
  let assetFallbacks = 0;
  const response = await worker.fetch(
    new Request(`https://rr-local.test${path}`, { method }),
    {
      ASSETS: {
        fetch: async () => {
          assetFallbacks += 1;
          return new Response("<!doctype html>", {
            headers: { "Content-Type": "text/html" },
          });
        },
      },
    } as any,
  );
  return { response, assetFallbacks };
}

test("Worker serves health from its API handler", async () => {
  const { response, assetFallbacks } = await request("/api/healthz");
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { status: "ok" });
  assert.equal(assetFallbacks, 0);
});

test("exact and nested unknown API routes return JSON 404 instead of SPA assets", async () => {
  for (const path of ["/api", "/api/not-a-route"]) {
    const { response, assetFallbacks } = await request(path);
    assert.equal(response.status, 404);
    assert.deepEqual(await response.json(), { error: "Not found" });
    assert.equal(assetFallbacks, 0);
  }
});

test("admin API fails closed with blank Clerk runtime values", async () => {
  const { response, assetFallbacks } = await request("/api/admin/leads");
  assert.equal(response.status, 401);
  assert.deepEqual(await response.json(), { error: "Authentication required" });
  assert.equal(assetFallbacks, 0);
});