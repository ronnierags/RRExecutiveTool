import assert from "node:assert/strict";
import { Buffer } from "node:buffer";
import test from "node:test";
import { onRequestPost } from "../functions/api/leads";
import { createCompensationPdf } from "../functions/_shared";

const scenarioNumbers = [
  "year", "yearsToModel", "marketReference", "baseSalary", "yearOneProRataPercent",
  "annualIncreasePercent", "targetIncentivePercent", "maximumMultiple", "annualEquityGrant",
  "equityVestingYears", "equityValueFactorPercent", "minimumAnnualCashGuarantee",
  "guaranteeDurationMonths", "severanceMonths", "changeInControlMultiple", "baseIncrease",
  "proration", "stiTarget", "stiMaximum", "guaranteedFloor", "floorFromYear", "floorToYear",
  "signOn", "signOnYear", "relocation", "relocationYear", "relocationGrossUp", "housingMonthly",
  "housingMonths", "housingYear", "housingGrossUp", "retentionBonus", "retentionYear",
  "rsuAnnualGrant", "rsuVestingYears", "psuAnnualTarget", "psuExpectedPayout", "psuVestingYears",
  "optionAnnualValue", "optionVestingYears", "equityStartYear", "phantomPool",
  "phantomCoefficient", "evMultiple", "baselineEv", "phantomVestingYears", "phantomCliffYears",
  "peOwnership", "peEntryValue", "peExitValue", "peExitYear", "peHurdle", "peRatchetOwnership",
  "peRatchetHurdle", "severanceMultiple", "severanceIncludesBonus", "severanceEquityAcceleration",
  "benefitsAnnual", "retirementAnnual",
];
const yearRowKeys = [
  "base", "incentive", "cash", "equity", "guaranteeTopUp", "totalComp", "revenue", "ebitda",
  "enterpriseValue", "evGrowth", "floor", "signOn", "relocation", "housing", "retention",
  "milestone", "rsu", "psu", "options", "phantom", "peExit", "benefits", "retirement", "longTerm",
  "severanceCash", "severanceEquity", "severanceTotal",
];
const allDisabled = {
  base: false,
  sti: false,
  floor: false,
  onetime: false,
  pubeq: false,
  phantom: false,
  pe: false,
  milestones: false,
  severance: false,
  benefits: false,
};

function scenario(brand: "rr" | "allsearch", includeSections = true) {
  return {
    ...Object.fromEntries(scenarioNumbers.map((key) => [key, 1])),
    brand,
    companyType: "Public",
    candidateRole: "Chief Executive Officer",
    valuationMethod: "ebitda",
    metrics: [{ name: "Revenue", weight: 100, achievement: 100 }],
    yearlyCompensation: [{
      year: "2026",
      ...Object.fromEntries(yearRowKeys.map((key, index) => [key, (index + 1) * 100])),
      totalComp: 2_400,
      cash: 1_700,
      equity: 700,
      guaranteeTopUp: 250,
    }],
    revenue: [1],
    ebitda: [1],
    equityGrowth: [1],
    manualEv: [1],
    scores: [[1]],
    ...(includeSections ? { enabledSections: { ...allDisabled } } : {}),
  };
}

function lead(brand: "rr" | "allsearch", consent: boolean, includeSections = true) {
  return {
    name: "Test Candidate",
    email: "candidate@example.test",
    company: "Example Co",
    role: "CEO",
    consent,
    scenario: scenario(brand, includeSections),
  };
}

function mockDb() {
  const calls: { sql: string; bindings: unknown[] }[] = [];
  return {
    calls,
    DB: {
      prepare(sql: string) {
        const call = { sql, bindings: [] as unknown[] };
        calls.push(call);
        return {
          bind(...bindings: unknown[]) {
            call.bindings = bindings;
            return {
              run: async () => ({ meta: { last_row_id: 42 } }),
            };
          },
        };
      },
    },
  };
}

async function postLead(input: unknown, notificationAddress?: string, mailConfigured = true) {
  const db = mockDb();
  const sentEmails: Record<string, unknown>[] = [];
  const originalFetch = globalThis.fetch;
  globalThis.fetch = (async (_url, init) => {
    sentEmails.push(JSON.parse(String(init?.body)) as Record<string, unknown>);
    return new Response("{}", { status: 200 });
  }) as typeof fetch;
  try {
    const request = new Request("https://example.test/api/leads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
    const env: Record<string, unknown> = {
      DB: db.DB,
      ...(mailConfigured ? {
        RR_EMAIL_FROM: "RR Test <plans@example.test>",
        EMAIL_FROM: "AllSearch Test <plans@example.test>",
        RESEND_API_KEY: "test-only-key",
      } : {}),
      ...(notificationAddress ? { LEAD_NOTIFICATION_EMAIL: notificationAddress } : {}),
    };
    const response = await onRequestPost({
      request,
      env: env as unknown as Parameters<typeof onRequestPost>[0]["env"],
    } as Parameters<typeof onRequestPost>[0]);
    return { response, dbCalls: db.calls, sentEmails };
  } finally {
    globalThis.fetch = originalFetch;
  }
}

test("RR private endpoint receipt sends only to the user with no notification address or D1 calls", async () => {
  const { response, dbCalls, sentEmails } = await postLead(lead("rr", false));
  assert.equal(response.status, 201);
  assert.equal(dbCalls.length, 0);
  assert.equal(sentEmails.length, 1);
  assert.deepEqual(sentEmails[0].to, ["candidate@example.test"]);
  assert.equal(Object.hasOwn(sentEmails[0], "bcc"), false);
  const receipt = await response.json() as { id?: number; pdfBase64: string; emailSent: boolean };
  assert.equal(receipt.id, undefined);
  assert.equal(receipt.emailSent, true);
  const pdf = Buffer.from(receipt.pdfBase64, "base64").toString("latin1");
  assert.match(pdf, /Year 1 total compensation: \$2,400/);
  assert.match(pdf, /Total \$2,400/);
  assert.doesNotMatch(pdf, /Starting base salary:|Annual increase:|Target incentive:|Contingent protections:|Top-up \$|INCENTIVE SCORECARD/);
  assert.doesNotMatch(pdf, /Public equity:|\(Base\)|\(Incentive\)|\(Equity\)/);
});

test("RR private endpoint still returns its PDF as download-only without email configuration", async () => {
  const { response, dbCalls, sentEmails } = await postLead(lead("rr", false), undefined, false);
  assert.equal(response.status, 201);
  assert.equal(dbCalls.length, 0);
  assert.equal(sentEmails.length, 0);
  const receipt = await response.json() as { id?: number; pdfBase64: string; emailSent: boolean };
  assert.equal(receipt.id, undefined);
  assert.equal(receipt.emailSent, false);
  assert.ok(receipt.pdfBase64.length > 0);
});

test("RR consented endpoint stores the lead and BCCs its notification address", async () => {
  const { response, dbCalls, sentEmails } = await postLead(lead("rr", true), "recruiter@example.test");
  assert.equal(response.status, 201);
  assert.equal(dbCalls.length, 2);
  assert.match(dbCalls[0].sql, /^INSERT INTO leads/);
  assert.match(dbCalls[1].sql, /^UPDATE leads/);
  assert.deepEqual(sentEmails[0].to, ["candidate@example.test"]);
  assert.deepEqual(sentEmails[0].bcc, ["recruiter@example.test"]);
  assert.equal((await response.json() as { id: number }).id, 42);
});

test("AllSearch false consent rejects before D1 or email side effects", async () => {
  const { response, dbCalls, sentEmails } = await postLead(lead("allsearch", false));
  assert.equal(response.status, 400);
  assert.equal(dbCalls.length, 0);
  assert.equal(sentEmails.length, 0);
});

test("legacy scenarios without enabledSections retain the original detail groups", () => {
  const input = lead("allsearch", true, false);
  const pdf = Buffer.from(createCompensationPdf(input)).toString("latin1");
  assert.match(pdf, /Starting base salary:/);
  assert.match(pdf, /Target incentive:/);
  assert.match(pdf, /Annual increase:/);
  assert.match(pdf, /\(Base\)/);
  assert.match(pdf, /\(Incentive\)/);
  assert.match(pdf, /\(Equity\)/);
  assert.match(pdf, /Top-up \$250 \| Total \$2,400/);
});

test("phantom and PE report groups follow their independent enabled flags", () => {
  const input: any = lead("rr", true);
  input.scenario.companyType = "Private";
  const privatePdf = Buffer.from(createCompensationPdf(input)).toString("latin1");
  assert.doesNotMatch(privatePdf, /Private phantom equity:/);
  assert.match(privatePdf, /Valuation method:/);

  input.scenario.companyType = "PE-backed";
  input.scenario.enabledSections = { ...allDisabled, phantom: true };
  const pePdf = Buffer.from(createCompensationPdf(input)).toString("latin1");
  assert.match(pePdf, /PE phantom equity:/);
  assert.doesNotMatch(pePdf, /PE ownership|Hurdle/);
});

test("section-aware RR PDFs use submitted Year 1 contingent severance and omit base-only details", async () => {
  const input: any = lead("rr", false);
  const s = input.scenario;
  s.baseSalary = 150_000;
  s.targetIncentivePercent = 60;
  s.severanceMultiple = 1;
  s.severanceMonths = 0;
  s.changeInControlMultiple = 0;
  s.enabledSections = { ...allDisabled, severance: true };
  s.yearlyCompensation[0].severanceCash = 240_000;
  s.yearlyCompensation[0].severanceEquity = 0;
  s.yearlyCompensation[0].severanceTotal = 240_000;

  const cloudflare = await postLead(input);
  assert.equal(cloudflare.response.status, 201);
  const receipt = await cloudflare.response.json() as { pdfBase64: string };
  const cloudflarePdf = Buffer.from(receipt.pdfBase64, "base64").toString("latin1");
  assert.match(cloudflarePdf, /Year 1 contingent severance reference: \$240,000/);
  assert.match(cloudflarePdf, /excluded from earned compensation/);
  assert.doesNotMatch(cloudflarePdf, /Annual increase:/);

});