import { readFile } from "node:fs/promises";

const config = await readFile(new URL("../wrangler.toml", import.meta.url), "utf8");
const value = (key) => {
  const match = config.match(new RegExp(`^${key}\\s*=\\s*"([^"]*)"`, "m"));
  return match?.[1]?.trim() ?? "";
};

const workerName = value("name");
const databaseId = value("database_id");
const databaseName = value("database_name");
const problems = [];

if (!workerName || /template|replace|placeholder|your[-_ ]/i.test(workerName)) {
  problems.push('Set wrangler.toml name to the real RR Worker name you chose or created.');
}
if (!/^[a-z0-9][a-z0-9-]{0,62}$/.test(workerName)) {
  problems.push("The Worker name must use lowercase letters, numbers, or hyphens (maximum 63 characters).");
}
if (
  !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(databaseId) ||
  databaseId === "00000000-0000-0000-0000-000000000000"
) {
  problems.push("Set the DB database_id to the actual D1 database UUID selected for this RR deployment.");
}
if (!databaseName || /template|replace|placeholder|your[-_ ]/i.test(databaseName)) {
  problems.push("Set the DB database_name to the actual D1 database name selected for this RR deployment.");
}

if (problems.length) {
  console.error("Deployment preflight blocked deployment:");
  for (const problem of problems) console.error(`- ${problem}`);
  console.error("No Worker deployment or database change was attempted.");
  process.exit(1);
}

console.log(`Deployment configuration looks populated for Worker "${workerName}" and D1 "${databaseName}".`);