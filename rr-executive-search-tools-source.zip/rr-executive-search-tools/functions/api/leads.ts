import {
  CreateLeadBody,
  CreateLeadResponse,
  createCompensationPdf,
  getLeadSharingPolicy,
  isLeadConsentValid,
  json,
  base64,
  type Env,
} from "../_shared";

export const onRequestPost: PagesFunction<Env> = async ({ request, env }) => {
  let body: unknown;
  try { body = await request.json(); } catch { return json({ error: "Invalid lead" }, 400); }
  const parsed = CreateLeadBody.safeParse(body);
  if (!parsed.success) return json({ error: "Invalid lead", details: parsed.error.flatten() }, 400);
  const lead = parsed.data;
  if (!isLeadConsentValid(lead)) {
    return json({
      error: "Invalid lead",
      details: { consent: "Consent may be false only for RR plans" },
    }, 400);
  }
  const sharing = getLeadSharingPolicy(lead);
  const isRr = lead.scenario.brand === "rr";
  try {
    let id: number | undefined;
    if (sharing.storeLead) {
      const createdAt = new Date().toISOString();
      const result = await env.DB.prepare(
        "INSERT INTO leads (name,email,company,role,consent,scenario,created_at,email_status) VALUES (?,?,?,?,?,?,?,?)",
      ).bind(lead.name, lead.email, lead.company, lead.role, 1, JSON.stringify(lead.scenario), createdAt, "failed").run();
      id = Number(result.meta.last_row_id);
    }
    const pdf = createCompensationPdf(lead);
    const fileName = `${isRr ? "rr-executive-search" : "allsearch"}-compensation-plan-${id ?? "private"}.pdf`;
    let emailSent = false;
    const from = isRr ? env.RR_EMAIL_FROM : env.EMAIL_FROM;
    const notify = env.LEAD_NOTIFICATION_EMAIL;
    if (env.RESEND_API_KEY && from && (!sharing.requiresNotificationAddress || notify)) {
      try {
        const response = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            from,
            to: [lead.email],
            ...(sharing.notifyRecruiter ? { bcc: [notify!] } : {}),
            subject: isRr ? "Your RR Executive Search Tools compensation plan" : "Your AllSearch executive compensation plan",
            html: `<p>Hi ${lead.name.replace(/[<>&"]/g, "")},</p><p>Your compensation plan is attached.</p>`,
            attachments: [{ filename: fileName, content: base64(pdf) }],
          }),
        });
        emailSent = response.ok;
      } catch { emailSent = false; }
    }
    if (id !== undefined) {
      await env.DB.prepare("UPDATE leads SET email_status = ? WHERE id = ?").bind(emailSent ? "sent" : "failed", id).run();
    }
    return json(CreateLeadResponse.parse({
      ...(id === undefined ? {} : { id }),
      pdfBase64: base64(pdf),
      fileName,
      emailSent,
    }), 201);
  } catch { return json({ error: "Unable to create lead" }, 500); }
};