import { defaultSectionEnabled } from "./scenario-model.ts";

export type Scenario = Record<string, any>;
export type ScenarioVersion = { id: string; name: string; scenario: Scenario; updatedAt: string };
export type ScenarioWorkspace = { format: "rr-compensation-versions"; version: 1; activeId: string; versions: ScenarioVersion[] };

export const WORKSPACE_KEY = "rr_comp_versions_v1";
const LEGACY_KEY = "rr_exec_comp";
export const MAX_VERSIONS = 25;
const MAX_BACKUP_BYTES = 2_000_000;
const arrayKeys = new Set(["metrics", "milestones", "rev", "ebitda", "eqGrowth", "manualEV", "scores"]);

function record(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function finite(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value) && Math.abs(value) <= 1e12;
}

function finiteArray(value: unknown, max = 15): value is number[] {
  return Array.isArray(value) && value.length <= max && value.every(finite);
}

/** Picks known calculator fields only; never inject untrusted JSON into component state. */
export function validateScenario(raw: unknown, defaults: Scenario, requireAllFields = false): Scenario {
  if (!record(raw)) throw new Error("A version has invalid calculator inputs.");
  if (requireAllFields && Object.keys(defaults).some(key => key !== "enabledSections" && !(key in raw))) {
    throw new Error("A version in the backup is missing calculator inputs.");
  }
  const scenario: Scenario = { ...defaults };
  for (const key of Object.keys(defaults)) {
    if (!(key in raw)) continue;
    const value = raw[key];
    if (key === "enabledSections") {
      if (!record(value) || Object.keys(defaultSectionEnabled).some(section => typeof value[section] !== "boolean")) {
        throw new Error("Invalid section settings in the saved file.");
      }
      scenario[key] = Object.fromEntries(Object.keys(defaultSectionEnabled).map(section => [section, value[section]]));
      continue;
    }
    if (arrayKeys.has(key)) {
      if (!Array.isArray(value)) throw new Error(`Invalid ${key} in the saved file.`);
      if (key === "scores") {
        if (value.length > 30 || !value.every(row => finiteArray(row))) throw new Error("Invalid annual scorecard values.");
        scenario[key] = value.map(row => [...row]);
      } else if (key === "metrics") {
        if (value.length > 30 || !value.every(m => record(m) && typeof m.name === "string" && m.name.length <= 200 && finite(m.weight) && (!("achievement" in m) || finite(m.achievement)))) throw new Error("Invalid scorecard metrics.");
        scenario[key] = value.map(m => ({
          name: m.name, weight: m.weight,
          ...(m.achievement !== undefined ? { achievement: m.achievement } : {}),
        }));
      } else if (key === "milestones") {
        if (value.length > 50 || !value.every(m => record(m) && typeof m.name === "string" && m.name.length <= 200 && typeof m.cat === "string" && m.cat.length <= 80 && finite(m.yr) && finite(m.amt))) throw new Error("Invalid milestone values.");
        scenario[key] = value.map(m => ({ name: m.name, cat: m.cat, yr: m.yr, amt: m.amt }));
      } else {
        if (!finiteArray(value)) throw new Error(`Invalid annual values in ${key}.`);
        scenario[key] = [...value];
      }
    } else if (typeof defaults[key] === "number") {
      if (!finite(value)) throw new Error(`Invalid value for ${key}.`);
      scenario[key] = value;
    } else if (typeof defaults[key] === "string") {
      if (typeof value !== "string" || value.length > 200) throw new Error(`Invalid value for ${key}.`);
      if (key === "type" && !["Public", "Private", "PE-backed"].includes(value)) throw new Error("Invalid company type.");
      if (key === "valMethod" && !["ebitda", "manual"].includes(value)) throw new Error("Invalid valuation method.");
      scenario[key] = value;
    } else if (typeof defaults[key] === "boolean") {
      if (typeof value !== "boolean") throw new Error(`Invalid value for ${key}.`);
      scenario[key] = value;
    }
  }
  if (!("enabledSections" in raw) && "enabledSections" in defaults) {
    scenario.enabledSections = Object.fromEntries(
      Object.keys(defaultSectionEnabled).map(section => [section, section === "severance" ? !!raw.includeSeverance : true]),
    );
  }
  return scenario;
}

function makeInitial(defaults: Scenario): ScenarioWorkspace {
  const id = crypto.randomUUID();
  return {
    format: "rr-compensation-versions", version: 1, activeId: id,
    versions: [{ id, name: "Version 1", scenario: structuredClone(defaults), updatedAt: new Date().toISOString() }],
  };
}

export function loadWorkspace(defaults: Scenario): { workspace: ScenarioWorkspace; warning: string } {
  const initial = makeInitial(defaults);
  try {
    const raw = localStorage.getItem(WORKSPACE_KEY);
    if (raw) {
      if (raw.length > MAX_BACKUP_BYTES) throw new Error("The stored workspace is too large.");
      return { workspace: parseWorkspace(JSON.parse(raw), defaults), warning: "" };
    }
    const legacy = localStorage.getItem(LEGACY_KEY);
    if (legacy) initial.versions[0].scenario = validateScenario(JSON.parse(legacy), defaults);
    return { workspace: initial, warning: "" };
  } catch {
    return {
      workspace: initial,
      warning: "Saved browser progress could not be read. Nothing has been overwritten; import a backup, or choose Save progress to start a new workspace.",
    };
  }
}

export function parseWorkspace(raw: unknown, defaults: Scenario): ScenarioWorkspace {
  if (!record(raw) || raw.format !== "rr-compensation-versions" || raw.version !== 1 || !Array.isArray(raw.versions) || raw.versions.length < 1 || raw.versions.length > MAX_VERSIONS) {
    throw new Error("This is not a supported RR calculator backup file.");
  }
  const ids = new Set<string>();
  const versions: ScenarioVersion[] = raw.versions.map((item: unknown) => {
    if (!record(item) || typeof item.id !== "string" || item.id.length < 1 || item.id.length > 100 || ids.has(item.id) ||
        typeof item.name !== "string" || !item.name.trim() || item.name.length > 80 ||
        typeof item.updatedAt !== "string" || Number.isNaN(Date.parse(item.updatedAt))) {
      throw new Error("A version in the backup has invalid details.");
    }
    ids.add(item.id);
    return { id: item.id, name: item.name.trim(), scenario: validateScenario(item.scenario, defaults, true), updatedAt: item.updatedAt };
  });
  if (typeof raw.activeId !== "string" || !ids.has(raw.activeId)) throw new Error("The backup has no valid active version.");
  return { format: "rr-compensation-versions", version: 1, activeId: raw.activeId, versions };
}

export function saveWorkspace(workspace: ScenarioWorkspace): void {
  localStorage.setItem(WORKSPACE_KEY, JSON.stringify(workspace));
}

export async function importWorkspace(file: File, defaults: Scenario): Promise<ScenarioWorkspace> {
  if (file.size > MAX_BACKUP_BYTES) throw new Error("This file is too large. Choose an RR calculator backup under 2 MB.");
  let raw: unknown;
  try { raw = JSON.parse(await file.text()); }
  catch { throw new Error("The selected file is not valid JSON."); }
  return parseWorkspace(raw, defaults);
}

export function mergeWorkspace(current: ScenarioWorkspace, incoming: ScenarioWorkspace): ScenarioWorkspace {
  if (current.versions.length + incoming.versions.length > MAX_VERSIONS) {
    throw new Error(`A browser workspace can hold up to ${MAX_VERSIONS} versions. Remove an old version before importing.`);
  }
  const versions = incoming.versions.map(version => ({ ...version, id: crypto.randomUUID(), scenario: structuredClone(version.scenario) }));
  const activeIndex = incoming.versions.findIndex(version => version.id === incoming.activeId);
  return { ...current, activeId: versions[activeIndex].id, versions: [...current.versions, ...versions] };
}