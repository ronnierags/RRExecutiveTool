/** The calculator model shared by the active scenario and saved-version comparison. */
export const defaultSectionEnabled = {
  base: true, sti: true, floor: false, onetime: false, pubeq: false,
  phantom: false, pe: false, milestones: false, severance: false, benefits: false,
};

export type SectionId = keyof typeof defaultSectionEnabled;

export function enabledForScenario(s: any, section: SectionId): boolean {
  // Scenarios saved before this setting existed retain their original modeled values.
  if (!s.enabledSections) return section === "severance" ? !!s.includeSeverance : true;
  return s.enabledSections[section] === true;
}

export function calculateScenario(s: any, seedMetrics: { name: string; weight: number; achievement: number }[]) {
  const n = (v: any) => Number(v) || 0;
  const years = Math.max(3, Math.min(10, n(s.years) || 7));
  const metrics = s.metrics?.length ? s.metrics : seedMetrics.map(m => ({ ...m, weight: m.weight / 100 }));
  const metricWeight = metrics.reduce((a: number, m: any) => a + n(m.weight), 0) || 1;
  return Array.from({ length: years }, (_, i) => {
    const y = i + 1, pf = i === 0 ? s.proration : 1,
      base = enabledForScenario(s, "base") ? n(s.base) * Math.pow(1 + n(s.baseInc), i) * pf : 0;
    let score = metrics.reduce((a: number, m: any, j: number) => a + n(m.weight) * (s.scores?.[j]?.[i] ?? 1), 0) / metricWeight;
    const sti = enabledForScenario(s, "sti") ? Math.min(n(s.stiMax) * base, base * n(s.stiTarget) * score) : 0,
      floor = enabledForScenario(s, "floor") && n(s.floor) && y >= n(s.floorFrom) && y <= n(s.floorTo) ? Math.max(0, n(s.floor) * pf - base - sti) : 0,
      ev = s.valMethod === "manual" && n(s.manualEV?.[i]) > 0 ? n(s.manualEV[i]) : n(s.ebitda?.[i]) * n(s.evMult),
      evg = n(s.eqGrowth?.[i]) > 0 ? n(s.eqGrowth[i]) : Math.max(0, ev - n(s.evBase)),
      once = enabledForScenario(s, "onetime") && y === n(s.signonYr) ? n(s.signon) : 0,
      reloc = enabledForScenario(s, "onetime") && y === n(s.relocYr) ? n(s.reloc) / (1 - n(s.relocGU)) : 0,
      housing = enabledForScenario(s, "onetime") && y === n(s.housingYr) ? n(s.housingMo) * n(s.housingMonths) / (1 - n(s.housingGU)) : 0,
      retention = enabledForScenario(s, "onetime") && y === n(s.retentionYr) ? n(s.retention) : 0,
      milestone = enabledForScenario(s, "milestones") ? (s.milestones || []).filter((m: any) => n(m.yr) === y).reduce((a: number, m: any) => a + n(m.amt), 0) : 0,
      vest = (g: number, v: number) => g && y >= n(s.eqStart) && y <= n(s.eqStart) + n(v) - 1 ? g / n(v) : 0,
      rsu = s.type === "Public" && enabledForScenario(s, "pubeq") ? vest(n(s.rsu), s.rsuVest) : 0,
      psu = s.type === "Public" && enabledForScenario(s, "pubeq") ? vest(n(s.psu) * n(s.psuPay), s.psuVest) : 0,
      opt = s.type === "Public" && enabledForScenario(s, "pubeq") ? vest(n(s.opt), s.optVest) : 0,
      phantom = s.type !== "Public" && enabledForScenario(s, "phantom") ? n(s.phantomPool) * evg * Math.min(1, Math.max(0, (y - n(s.phCliff)) / n(s.phVest))) : 0,
      moic = n(s.peEntry) ? n(s.peExit) / n(s.peEntry) : 0,
      peExit = s.type === "PE-backed" && enabledForScenario(s, "pe") && y === n(s.peExitYr) && moic >= n(s.peHurdle) ? (n(s.peOwn) + (moic >= n(s.peHurdle2) ? n(s.peOwn2) : 0)) * Math.max(0, n(s.peExit) - n(s.peEntry)) : 0,
      cash = base + sti + floor + once + reloc + housing + retention + milestone + (enabledForScenario(s, "benefits") ? n(s.perks) + n(s.retire) : 0),
      longTerm = rsu + psu + opt + phantom + peExit;
    return {
      year: String(n(s.year) + i), base, sti, floor, signon: once, reloc, housing, retention, milestone,
      rsu, psu, opt, phantom, peExit, perks: enabledForScenario(s, "benefits") ? n(s.perks) : 0, retire: enabledForScenario(s, "benefits") ? n(s.retire) : 0, ev, evg,
      ebitda: n(s.ebitda?.[i]), revenue: n(s.rev?.[i]), cash, longTerm, equity: longTerm,
      totalComp: cash + longTerm,
      severanceCash: enabledForScenario(s, "severance") ? n(s.sevMult) * (base + (s.sevInclBonus && enabledForScenario(s, "sti") ? base * n(s.stiTarget) : 0)) : 0,
      severanceEquity: enabledForScenario(s, "severance") && enabledForScenario(s, "phantom") && s.type !== "Public" ? n(s.sevAccel) * Math.max(0, n(s.phantomPool) * evg - phantom) : 0,
    };
  });
}