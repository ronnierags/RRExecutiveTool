import { useCallback, useEffect, useMemo, useRef, useState, type SetStateAction } from "react";
import { calculateScenario } from "./scenario-model";
import {
  importWorkspace, loadWorkspace, MAX_VERSIONS, mergeWorkspace, saveWorkspace,
  type Scenario, type ScenarioWorkspace,
} from "./scenario-workspace";
import type { ScenarioSummary } from "./VersionWorkspace";

export function useScenarioWorkspace(
  defaults: Scenario,
  seedMetrics: { name: string; weight: number; achievement: number }[],
) {
  const [loaded] = useState(() => loadWorkspace(defaults));
  const [workspace, setWorkspaceState] = useState<ScenarioWorkspace>(loaded.workspace);
  const workspaceRef = useRef(workspace);
  const setWorkspace = useCallback((change: SetStateAction<ScenarioWorkspace>) => {
    const next = typeof change === "function" ? change(workspaceRef.current) : change;
    workspaceRef.current = next;
    setWorkspaceState(next);
  }, []);
  const [selectedIds, setSelectedIds] = useState<string[]>([loaded.workspace.activeId]);
  const [status, setStatus] = useState("");
  const [error, setError] = useState(loaded.warning);
  const [blocked, setBlocked] = useState(Boolean(loaded.warning));
  const active = workspace.versions.find(version => version.id === workspace.activeId)!;

  useEffect(() => {
    if (blocked) return;
    try {
      saveWorkspace(workspace);
      setError("");
    } catch {
      setError("Browser storage is full or unavailable. Download a backup file to protect these changes.");
    }
  }, [workspace, blocked]);

  const setScenario = (change: SetStateAction<Scenario>) => {
    setWorkspace(current => ({
      ...current,
      versions: current.versions.map(version => version.id === current.activeId
        ? {
          ...version,
          scenario: typeof change === "function" ? change(version.scenario) : change,
          updatedAt: new Date().toISOString(),
        }
        : version),
    }));
    setStatus("");
  };

  const summaries: ScenarioSummary[] = useMemo(
    () => workspace.versions.map(version => {
      const rows = calculateScenario(version.scenario, seedMetrics);
      return {
        id: version.id,
        name: version.name,
        companyType: version.scenario.type,
        yearOne: rows[0]?.totalComp ?? 0,
        cumulative: rows.reduce((sum, row) => sum + row.totalComp, 0),
        yearOneCash: rows[0]?.cash ?? 0,
        longTermTotal: rows.reduce((sum, row) => sum + row.longTerm, 0),
        peakLongTerm: Math.max(0, ...rows.map(row => row.longTerm)),
        years: rows.length,
        yearlyTotals: rows.map(row => row.totalComp),
        startYear: Number(version.scenario.year) || 2026,
      };
    }),
    [workspace.versions],
  );

  const onCreate = () => {
    if (workspace.versions.length >= MAX_VERSIONS) {
      setError(`A browser workspace can hold up to ${MAX_VERSIONS} versions.`);
      return;
    }
    const id = crypto.randomUUID();
    const name = `Version ${workspace.versions.length + 1}`;
    setWorkspace(current => ({
      ...current,
      activeId: id,
      versions: [...current.versions, { id, name, scenario: structuredClone(active.scenario), updatedAt: new Date().toISOString() }],
    }));
    setSelectedIds(ids => [...ids, id].slice(-4));
    setStatus(`${name} created from ${active.name}. Edit it independently.`);
  };

  const onRename = (id: string, name: string) => {
    const trimmed = name.trim();
    if (!trimmed || trimmed.length > 80) {
      setError("Version names must be 1–80 characters.");
      return;
    }
    setWorkspace(current => ({
      ...current,
      versions: current.versions.map(version => version.id === id ? { ...version, name: trimmed } : version),
    }));
    setStatus("Version renamed.");
  };

  const onDelete = (id: string) => {
    if (workspace.versions.length === 1) {
      setError("Keep at least one version. Use Reset to clear its inputs instead.");
      return;
    }
    setWorkspace(current => {
      const versions = current.versions.filter(version => version.id !== id);
      return { ...current, versions, activeId: current.activeId === id ? versions[0].id : current.activeId };
    });
    setSelectedIds(ids => ids.filter(item => item !== id));
    setStatus("Version deleted from this browser.");
  };

  const onSave = () => {
    try {
      saveWorkspace(workspace);
      setBlocked(false);
      setError("");
      setStatus("All versions saved in this browser.");
    } catch {
      setError("Browser storage is full or unavailable. Download a backup file to protect these changes.");
    }
  };

  const onExport = () => {
    const blob = new Blob([JSON.stringify(workspace, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `rr-compensation-versions-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    setStatus("Backup downloaded. Keep the JSON file somewhere safe to restore these versions later.");
  };

  const onImport = async (file: File) => {
    try {
      const imported = await importWorkspace(file, defaults);
      // File reading is asynchronous: preserve edits made while the backup was read.
      const merged = mergeWorkspace(workspaceRef.current, imported);
      saveWorkspace(merged);
      setWorkspace(merged);
      setSelectedIds(imported.versions.length <= 4 ? merged.versions.slice(-imported.versions.length).map(v => v.id) : [merged.activeId]);
      setBlocked(false);
      setError("");
      setStatus(`${imported.versions.length} version${imported.versions.length === 1 ? "" : "s"} imported. Existing versions were kept.`);
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : "Unable to import this backup file.");
    }
  };

  return {
    scenario: active.scenario, setScenario, workspace, selectedIds, summaries, status, error,
    onCreate, onRename, onDelete, onSave, onExport, onImport,
    onSelect: (id: string) => {
      if (workspace.versions.some(version => version.id === id)) {
        setWorkspace(current => ({ ...current, activeId: id }));
        setStatus("");
      }
    },
    onToggleComparison: (id: string) => setSelectedIds(current => current.includes(id)
      ? current.filter(item => item !== id)
      : current.length < 4 ? [...current, id] : current),
  };
}