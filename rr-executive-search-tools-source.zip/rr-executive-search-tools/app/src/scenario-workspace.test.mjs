import assert from "node:assert/strict";
import { test } from "node:test";
import { calculateScenario, defaultSectionEnabled } from "./scenario-model.ts";
import { loadWorkspace, mergeWorkspace, parseWorkspace, validateScenario } from "./scenario-workspace.ts";

const defaults = {
  type: "Private", candidate: "", year: 2026, years: 3, base: 0, baseInc: .03,
  proration: 1, stiTarget: .6, stiMax: 1.5, floor: 0, floorFrom: 1, floorTo: 2,
  signon: 0, signonYr: 1, reloc: 0, relocYr: 1, relocGU: 0,
  housingMo: 0, housingMonths: 0, housingYr: 1, housingGU: 0,
  retention: 0, retentionYr: 2, eqStart: 1, rsu: 0, rsuVest: 4, psu: 0,
  psuPay: 1, psuVest: 3, opt: 0, optVest: 4, valMethod: "ebitda",
  evMult: 6, evBase: 0, phantomPool: .05, phVest: 5, phCliff: 1,
  peEntry: 0, peExit: 0, peExitYr: 3, peHurdle: 2, peOwn: 0,
  peOwn2: 0, peHurdle2: 3, perks: 0, retire: 0, sevMult: 1,
  sevInclBonus: 1, sevAccel: 1, includeSeverance: false,
  metrics: [{ name: "Target", weight: 1 }], milestones: [], scores: [],
  rev: [], ebitda: [], eqGrowth: [], manualEV: [],
};
const version = (id, base) => ({
  id, name: id, updatedAt: "2026-09-28T00:00:00.000Z",
  scenario: { ...defaults, base },
});
const backup = (id, base) => ({
  format: "rr-compensation-versions", version: 1, activeId: id,
  versions: [version(id, base)],
});

test("comparison runs the same compensation model for each version", () => {
  const first = calculateScenario(version("One", 150000).scenario, []);
  const second = calculateScenario(version("Two", 200000).scenario, []);
  assert.equal(first[0].totalComp, 240000);
  assert.equal(second[0].totalComp, 320000);
  assert.equal(first[1].totalComp, 247200);
});

test("a backup imports alongside existing versions without changing existing scenarios", () => {
  const existing = parseWorkspace(backup("a", 150000), defaults);
  const incoming = parseWorkspace(backup("b", 200000), defaults);
  const merged = mergeWorkspace(existing, incoming);
  assert.equal(merged.versions.length, 2);
  assert.equal(merged.versions[0].scenario.base, 150000);
  assert.equal(merged.versions[1].scenario.base, 200000);
  assert.notEqual(merged.versions[0].id, merged.versions[1].id);
  assert.equal(merged.activeId, merged.versions[1].id);
  assert.equal(parseWorkspace(JSON.parse(JSON.stringify(merged)), defaults).versions.length, 2);
});

test("invalid or incomplete backup inputs are rejected rather than replacing progress", () => {
  assert.throws(() => parseWorkspace(backup("a", Infinity), defaults), /Invalid value/);
  assert.throws(() => parseWorkspace(backup("a", 150000).versions[0].scenario, defaults), /not a supported/);
  assert.throws(() => parseWorkspace(backup("a", 150000), { ...defaults, anotherField: 1 }), /missing calculator inputs/);
  assert.throws(() => validateScenario({ ...defaults, metrics: [{ name: "Target", weight: "bad" }] }, defaults), /metrics/);
});

test("disabled sections contribute zero without deleting stored inputs", () => {
  const scenario = {
    ...defaults, base: 150000, signon: 30000, perks: 5000, retire: 10000,
    milestones: [{ name: "Milestone", cat: "Target", yr: 1, amt: 50000 }],
    ebitda: [1000000, 1200000, 1400000], phCliff: 0,
    enabledSections: { ...defaultSectionEnabled },
  };
  const disabled = calculateScenario(scenario, []);
  assert.equal(disabled[0].totalComp, 240000);
  assert.equal(disabled[0].milestone, 0);
  assert.equal(disabled[0].phantom, 0);
  assert.equal(disabled[0].perks, 0);
  assert.equal(scenario.signon, 30000);
  const enabled = calculateScenario({
    ...scenario,
    enabledSections: { ...scenario.enabledSections, onetime: true, milestones: true, benefits: true, phantom: true },
  }, []);
  assert.equal(enabled[0].signon, 30000);
  assert.equal(enabled[0].milestone, 50000);
  assert.equal(enabled[0].phantom, 60000);
  assert.equal(enabled[0].totalComp, 395000);
});

test("section selections round-trip in backups and legacy scenarios keep their modeled values", () => {
  const newDefaults = { ...defaults, enabledSections: { ...defaultSectionEnabled } };
  const old = backup("legacy", 150000);
  old.versions[0].scenario.signon = 30000;
  old.versions[0].scenario.metrics[0].achievement = 100;
  const migrated = parseWorkspace(old, newDefaults);
  assert.equal(migrated.versions[0].scenario.enabledSections.onetime, true);
  assert.equal(migrated.versions[0].scenario.metrics[0].achievement, 100);
  assert.equal(calculateScenario(migrated.versions[0].scenario, [])[0].signon, 30000);
  migrated.versions[0].scenario.enabledSections.onetime = false;
  const reloaded = parseWorkspace(JSON.parse(JSON.stringify(migrated)), newDefaults);
  assert.equal(reloaded.versions[0].scenario.enabledSections.onetime, false);
  assert.equal(reloaded.versions[0].scenario.signon, 30000);
  assert.equal(calculateScenario(reloaded.versions[0].scenario, [])[0].signon, 0);
  reloaded.versions[0].scenario.enabledSections.onetime = "bad";
  assert.throws(() => parseWorkspace(reloaded, newDefaults), /Invalid section settings/);
});

test("unavailable browser storage produces a warning rather than crashing the calculator", () => {
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true, value: { getItem() { throw new Error("Storage denied"); } },
  });
  try {
    const loaded = loadWorkspace(defaults);
    assert.equal(loaded.workspace.versions.length, 1);
    assert.match(loaded.warning, /Nothing has been overwritten/);
  } finally {
    if (descriptor) Object.defineProperty(globalThis, "localStorage", descriptor);
    else delete globalThis.localStorage;
  }
});