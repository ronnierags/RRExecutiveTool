import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { ArrowDownToLine, Check, ChevronDown, FileUp, GitCompareArrows, Pencil, Plus, Save, Trash2, X } from "lucide-react";
import "./VersionWorkspace.css";

export type ScenarioVersion = { id: string; name: string; updatedAt: string };
export type ScenarioSummary = {
  id: string;
  name: string;
  companyType: string;
  yearOne: number;
  cumulative: number;
  yearOneCash: number;
  longTermTotal: number;
  peakLongTerm: number;
  years: number;
  yearlyTotals: number[];
  startYear: number;
};

export type VersionWorkspaceProps = {
  versions: ScenarioVersion[];
  activeId: string;
  selectedIds: string[];
  summaries: ScenarioSummary[];
  onSelect(id: string): void;
  onCreate(): void;
  onRename(id: string, name: string): void;
  onDelete(id: string): void;
  onToggleComparison(id: string): void;
  onSave(): void;
  onExport(): void;
  onImport(file: File): Promise<void>;
  status: string;
  error: string;
};

const currency = (value: number) =>
  Number.isFinite(value)
    ? new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(value)
    : "—";

function formatUpdatedAt(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : new Intl.DateTimeFormat("en-US", { dateStyle: "medium", timeStyle: "short" }).format(date);
}

export default function VersionWorkspace({
  versions,
  activeId,
  selectedIds,
  summaries,
  onSelect,
  onCreate,
  onRename,
  onDelete,
  onToggleComparison,
  onSave,
  onExport,
  onImport,
  status,
  error,
}: VersionWorkspaceProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const deleteCancelRef = useRef<HTMLButtonElement>(null);
  const deleteOpenerRef = useRef<HTMLButtonElement>(null);
  const wasDeleteDialogOpenRef = useRef(false);
  const [renaming, setRenaming] = useState(false);
  const [comparisonOpen, setComparisonOpen] = useState(false);
  const [renameValue, setRenameValue] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<ScenarioVersion | null>(null);
  const importLabelId = "rr-version-import-label";
  const activeVersion = versions.find((version) => version.id === activeId);
  const selectedSummaries = selectedIds
    .slice(0, 4)
    .map((id) => summaries.find((summary) => summary.id === id))
    .filter((summary): summary is ScenarioSummary => Boolean(summary));

  useEffect(() => {
    if (deleteTarget) {
      wasDeleteDialogOpenRef.current = true;
      deleteCancelRef.current?.focus();
    } else if (wasDeleteDialogOpenRef.current) {
      wasDeleteDialogOpenRef.current = false;
      deleteOpenerRef.current?.focus();
    }
  }, [deleteTarget]);

  const beginRename = () => {
    if (!activeVersion) return;
    setRenameValue(activeVersion.name);
    setRenaming(true);
  };

  const submitRename = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextName = renameValue.trim();
    if (!activeVersion || !nextName) return;
    onRename(activeVersion.id, nextName);
    setRenaming(false);
  };

  const importFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;
    try {
      await onImport(file);
    } finally {
      input.value = "";
    }
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    onDelete(deleteTarget.id);
    setDeleteTarget(null);
  };

  return (
    <section className="rr-version-workspace" aria-labelledby="rr-version-title">
      <div className="rr-vw-heading">
        <div>
          <div className="rr-vw-eyebrow">Scenario workspace</div>
          <h2 id="rr-version-title">Versions &amp; comparison</h2>
          <p>Keep a clear record of each compensation proposal and compare the outcomes.</p>
        </div>
        <button className="rr-vw-button rr-vw-button-primary rr-vw-new" type="button" onClick={onCreate} data-testid="button-new-version">
          <Plus size={16} aria-hidden="true" />
          New version (clone)
        </button>
      </div>

      <div className="rr-vw-management">
        <div className="rr-vw-version-controls">
          <label className="rr-vw-field-label" htmlFor="rr-version-picker">Version picker</label>
          <div className="rr-vw-picker-wrap">
            <select
              id="rr-version-picker"
              className="rr-vw-picker"
              value={activeVersion ? activeId : ""}
              onChange={(event) => onSelect(event.target.value)}
              data-testid="select-version"
            >
              {!activeVersion && <option value="">Choose a version</option>}
              {versions.map((version) => (
                <option value={version.id} key={version.id}>{version.name}</option>
              ))}
            </select>
            <ChevronDown size={15} aria-hidden="true" />
          </div>
          <div className="rr-vw-updated" aria-live="polite">
            {activeVersion ? <>Current version <strong>{activeVersion.name}</strong><span>Updated {formatUpdatedAt(activeVersion.updatedAt)}</span></> : "No version selected"}
          </div>
        </div>

        <div className="rr-vw-actions" aria-label="Version actions">
          {!renaming ? (
            <button className="rr-vw-button rr-vw-button-secondary" type="button" onClick={beginRename} disabled={!activeVersion} data-testid="button-rename-version">
              <Pencil size={14} aria-hidden="true" /> Rename
            </button>
          ) : (
            <form className="rr-vw-rename-form" onSubmit={submitRename}>
              <label className="rr-vw-sr-only" htmlFor="rr-version-rename">New version name</label>
              <input id="rr-version-rename" value={renameValue} onChange={(event) => setRenameValue(event.target.value)} autoFocus maxLength={80} required data-testid="input-version-name" />
              <button className="rr-vw-icon-button" type="submit" aria-label="Save version name" disabled={!renameValue.trim()} data-testid="button-save-rename"><Check size={16} /></button>
              <button className="rr-vw-icon-button" type="button" aria-label="Cancel rename" onClick={() => setRenaming(false)} data-testid="button-cancel-rename"><X size={16} /></button>
            </form>
          )}
          <button ref={deleteOpenerRef} className="rr-vw-button rr-vw-button-danger" type="button" onClick={(event) => { if (activeVersion) { deleteOpenerRef.current = event.currentTarget; setDeleteTarget(activeVersion); } }} disabled={versions.length <= 1} title={versions.length <= 1 ? "Keep at least one version" : undefined} data-testid="button-delete-version">
            <Trash2 size={14} aria-hidden="true" /> Delete
          </button>
          <span className="rr-vw-action-divider" aria-hidden="true" />
          <button className="rr-vw-button rr-vw-button-secondary" type="button" onClick={onSave} data-testid="button-save-progress">
            <Save size={14} aria-hidden="true" /> Save progress (browser)
          </button>
          <button className="rr-vw-button rr-vw-button-secondary" type="button" onClick={onExport} data-testid="button-export-backup">
            <ArrowDownToLine size={14} aria-hidden="true" /> Download backup JSON
          </button>
          <input
            className="rr-vw-file-input"
            ref={fileInputRef}
            id="rr-version-import"
            type="file"
            accept=".json,application/json"
            onChange={importFile}
            aria-labelledby={importLabelId}
            data-testid="input-import-backup"
          />
          <button className="rr-vw-button rr-vw-button-secondary" type="button" onClick={() => fileInputRef.current?.click()} data-testid="button-import-backup">
            <FileUp size={14} aria-hidden="true" /> <span id={importLabelId}>Import backup JSON</span>
          </button>
        </div>
      </div>

      <div className="rr-vw-local-note">
        <span className="rr-vw-note-mark" aria-hidden="true">i</span>
        <p>Versions and saved progress stay in this browser; they are not account or cloud synced. Download a JSON backup to transfer scenarios to another computer.</p>
      </div>

      {(status || error) && (
        <div className={`rr-vw-feedback${error ? " is-error" : ""}`} role={error ? "alert" : "status"} data-testid={error ? "status-version-error" : "status-version-message"}>
          {error || status}
        </div>
      )}

      <button
        className="rr-vw-compare-disclosure"
        type="button"
        aria-expanded={comparisonOpen}
        aria-controls="rr-vw-comparison-content"
        onClick={() => setComparisonOpen((open) => !open)}
        data-testid="button-toggle-comparison"
      >
        <span className="rr-vw-disclosure-copy">
          <span className="rr-vw-disclosure-title"><GitCompareArrows size={17} aria-hidden="true" /> Compare scenarios</span>
          <span className="rr-vw-disclosure-action">{comparisonOpen ? "Hide comparison" : "Show comparison"}</span>
        </span>
        <span className="rr-vw-count" aria-live="polite">{selectedIds.length} / 4 selected</span>
        <ChevronDown className={comparisonOpen ? "rr-vw-chevron is-open" : "rr-vw-chevron"} size={16} aria-hidden="true" />
      </button>

      {versions.length === 1 && !comparisonOpen && (
        <p className="rr-vw-single-version-hint">Create a second version to compare scenarios.</p>
      )}
      {versions.length === 0 && (
        <div className="rr-vw-empty">
          <strong>No saved versions yet</strong>
          <span>Create a version to preserve this scenario and begin comparing options.</span>
        </div>
      )}

      <div id="rr-vw-comparison-content" className="rr-vw-comparison-content" hidden={!comparisonOpen}>
        {comparisonOpen && versions.length === 1 && (
          <p className="rr-vw-single-version-hint">Create a second version to compare scenarios.</p>
        )}
        {comparisonOpen && versions.length > 1 && (
        <div className="rr-vw-expanded-comparison">
          <div className="rr-vw-select-list" aria-label="Versions available for comparison">
            {versions.map((version) => {
              const checked = selectedIds.includes(version.id);
              const limitReached = selectedIds.length >= 4 && !checked;
              return (
                <label className={`rr-vw-select-item${checked ? " is-selected" : ""}${limitReached ? " is-disabled" : ""}`} key={version.id}>
                  <input
                    type="checkbox"
                    checked={checked}
                    disabled={limitReached}
                    onChange={() => onToggleComparison(version.id)}
                    aria-label={`Compare ${version.name}`}
                    data-testid={`checkbox-compare-${version.id}`}
                  />
                  <span className="rr-vw-checkmark" aria-hidden="true"><Check size={12} /></span>
                  <span className="rr-vw-select-name">{version.name}</span>
                  {version.id === activeId && <span className="rr-vw-active-tag">Current</span>}
                </label>
              );
            })}
          </div>
          {selectedIds.length > 0 && selectedSummaries.length === 0 ? (
            <p className="rr-vw-no-summary">Comparison figures are not available for the selected versions yet.</p>
          ) : selectedSummaries.length > 0 ? (
        <div className="rr-vw-table-scroll" role="region" aria-label="Scenario comparison results" tabIndex={0}>
          <table className="rr-vw-comparison">
            <caption>Compensation outcomes by selected scenario</caption>
            <thead>
              <tr>
                <th scope="col">Measure</th>
                {selectedSummaries.map((summary) => (
                  <th scope="col" key={summary.id}>
                    <span className="rr-vw-table-name">{summary.name}</span>
                    <span className="rr-vw-table-meta">{summary.companyType} · {summary.years} years</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {([
                ["Year 1 total", (s: ScenarioSummary) => currency(s.yearOne)],
                ["Cumulative total", (s: ScenarioSummary) => currency(s.cumulative)],
                ["Year 1 cash", (s: ScenarioSummary) => currency(s.yearOneCash)],
                ["Long-term total", (s: ScenarioSummary) => currency(s.longTermTotal)],
                ["Peak long-term / year", (s: ScenarioSummary) => currency(s.peakLongTerm)],
              ] as const).map(([label, value]) => (
                <tr key={label}>
                  <th scope="row">{label}</th>
                  {selectedSummaries.map((summary) => <td key={summary.id}>{value(summary)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>

          <div className="rr-vw-chart" role="group" aria-label="Year-by-year total compensation comparison">
            <div className="rr-vw-chart-title">Year-by-year total</div>
            {selectedSummaries.map((summary, scenarioIndex) => {
              const max = Math.max(1, ...selectedSummaries.flatMap((item) => item.yearlyTotals.map((amount) => Math.max(0, amount))));
              return (
                <div className="rr-vw-series" key={summary.id}>
                  <div className="rr-vw-series-name"><span className={`rr-vw-series-swatch swatch-${scenarioIndex}`} aria-hidden="true" />{summary.name}</div>
                  <div className="rr-vw-bars" aria-label={`${summary.name} yearly compensation`}>
                    {summary.yearlyTotals.map((amount, index) => {
                      const year = summary.startYear + index;
                      const height = Math.max(3, (Math.max(0, amount) / max) * 100);
                      return (
                        <div className="rr-vw-bar-column" key={`${summary.id}-${year}`} title={`${year}: ${currency(amount)}`}>
                          <span className="rr-vw-bar-value">{currency(amount)}</span>
                          <span
                            className={`rr-vw-bar swatch-${scenarioIndex}`}
                            style={{ height: `${height}%` }}
                            role="img"
                            aria-label={`${year}: ${currency(amount)}`}
                          />
                          <span className="rr-vw-bar-year">{year}</span>
                        </div>
                      );
                    })}
                    {!summary.yearlyTotals.length && <span className="rr-vw-chart-empty">Yearly figures unavailable</span>}
                  </div>
                </div>
              );
            })}
            <p className="rr-vw-chart-note">Bar height is scaled across the selected scenarios; exact values are provided on each bar.</p>
          </div>
        </div>
          ) : null}
        </div>
        )}
      </div>

      {deleteTarget && (
        <div className="rr-vw-dialog-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setDeleteTarget(null); }}>
          <section className="rr-vw-delete-dialog" role="alertdialog" aria-modal="true" aria-labelledby="rr-vw-delete-title" aria-describedby="rr-vw-delete-description" onKeyDown={(event) => { if (event.key === "Escape") setDeleteTarget(null); }}>
            <div className="rr-vw-dialog-icon"><Trash2 size={18} aria-hidden="true" /></div>
            <h3 id="rr-vw-delete-title">Delete this version?</h3>
            <p id="rr-vw-delete-description"><strong>{deleteTarget.name}</strong> will be removed from this browser’s version list. This cannot be undone.</p>
            <div className="rr-vw-dialog-actions">
              <button ref={deleteCancelRef} className="rr-vw-button rr-vw-button-secondary" type="button" onClick={() => setDeleteTarget(null)} data-testid="button-cancel-delete">Keep version</button>
              <button className="rr-vw-button rr-vw-button-danger-solid" type="button" onClick={confirmDelete} data-testid="button-confirm-delete">Delete version</button>
            </div>
          </section>
        </div>
      )}
    </section>
  );
}